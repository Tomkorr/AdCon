package com.example.AdWall_Android

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns
import com.example.AdWall_Android.DataBase.SQL_CREATE_ENTRIES_HARMONOGRAM
import com.example.AdWall_Android.DataBase.SQL_CREATE_ENTRIES_MEDIA
import com.example.AdWall_Android.DataBase.SQL_CREATE_ENTRIES_MODULE
import com.example.AdWall_Android.DataBase.SQL_CREATE_ENTRIES_SETTINGS
import com.example.AdWall_Android.DataBase.SQL_DELETE_ENTRIES_MODULE

object DataBase {

    object MediaEntry : BaseColumns {
        const val TABLE_MEDIA = "MEDIA"
        const val TABLE_COLUMN_MEDIA_ID = "MEDIA_ID"
        const val TABLE_COLUMN_NAME = "NAME"
        const val TABLE_COLUMN_PATH = "PATH"
        const val TABLE_COLUMN_TYP = "TYP"
        const val TABLE_COLUMN_SIZE = "SIZE"
    }

    object HarmonogramEntry : BaseColumns {
        const val TABLE_HARMONOGRAM = "HARMONOGRAM"
        const val TABLE_COLUMN_HARMONOGRAM_ID = "HARMONOGRAM_ID"
        const val TABLE_COLUMN_MODULS_ID = "MODULS_ID"
        const val TABLE_COLUMN_DAY_ID = "DAY_ID"
        const val TABLE_COLUMN_TIME_START = "TIME_START"
        const val TABLE_COLUMN_TIME_STOP = "TIME_STOP"
    }

    object ModuleEntry : BaseColumns {
        const val TABLE_MODULE = "MODULE"
        const val TABLE_COLUMN_MODULE_ID = "MODULE_ID"
        const val TABLE_COLUMN_NAME = "NAME"
        const val TABLE_COLUMN_MEDIA_ID = "MEDIA_ID"
        const val TABLE_COLUMN_TIME= "TIME"
    }

    object SettingsEntry : BaseColumns {
        const val TABLE_SETTINGS = "SETTINGS"
        const val TABLE_COLUMN_INFORMATION_BAR = "INFORMATION_BAR"
        const val TABLE_COLUMN_ID_SYNCH = "ID_SYNCH"
    }

    const val SQL_CREATE_ENTRIES_MEDIA =
        "CREATE TABLE ${MediaEntry.TABLE_MEDIA} (" +
                "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                "${MediaEntry.TABLE_COLUMN_MEDIA_ID} INTEGER," +
                "${MediaEntry.TABLE_COLUMN_NAME} TEXT," +
                "${MediaEntry.TABLE_COLUMN_PATH} TEXT," +
                "${MediaEntry.TABLE_COLUMN_TYP} INTEGER," +
                "${MediaEntry.TABLE_COLUMN_SIZE} INTEGER," +
                "UNIQUE(${MediaEntry.TABLE_COLUMN_MEDIA_ID},${MediaEntry.TABLE_COLUMN_NAME},${MediaEntry.TABLE_COLUMN_PATH},${MediaEntry.TABLE_COLUMN_TYP},${MediaEntry.TABLE_COLUMN_SIZE}))"

    const val SQL_CREATE_ENTRIES_HARMONOGRAM =
        "CREATE TABLE ${HarmonogramEntry.TABLE_HARMONOGRAM} (" +
                "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                "${HarmonogramEntry.TABLE_COLUMN_HARMONOGRAM_ID} INTEGER," +
                "${HarmonogramEntry.TABLE_COLUMN_MODULS_ID} INTEGER," +
                "${HarmonogramEntry.TABLE_COLUMN_DAY_ID} INTEGER," +
                "${HarmonogramEntry.TABLE_COLUMN_TIME_START} TEXT," +
                "${HarmonogramEntry.TABLE_COLUMN_TIME_STOP} TEXT," +
                "UNIQUE(${HarmonogramEntry.TABLE_COLUMN_HARMONOGRAM_ID},${HarmonogramEntry.TABLE_COLUMN_MODULS_ID},${HarmonogramEntry.TABLE_COLUMN_DAY_ID},${HarmonogramEntry.TABLE_COLUMN_TIME_START}," +
                "${HarmonogramEntry.TABLE_COLUMN_TIME_STOP}))"

    const val SQL_CREATE_ENTRIES_MODULE=
        "CREATE TABLE ${ModuleEntry.TABLE_MODULE} (" +
                "${ModuleEntry.TABLE_COLUMN_MODULE_ID} INTEGER," +
                "${ModuleEntry.TABLE_COLUMN_NAME} TEXT," +
                "${ModuleEntry.TABLE_COLUMN_MEDIA_ID} INTEGER," +
                "${ModuleEntry.TABLE_COLUMN_TIME} INTEGER, " +
                "UNIQUE(${ModuleEntry.TABLE_COLUMN_MODULE_ID},${ModuleEntry.TABLE_COLUMN_NAME},${ModuleEntry.TABLE_COLUMN_MEDIA_ID},${ModuleEntry.TABLE_COLUMN_TIME}))"

    const val SQL_CREATE_ENTRIES_SETTINGS=
        "CREATE TABLE ${SettingsEntry.TABLE_SETTINGS} (" +
                "${SettingsEntry.TABLE_COLUMN_ID_SYNCH} INTEGER," +
                "${SettingsEntry.TABLE_COLUMN_INFORMATION_BAR} TEXT)"

    const val SQL_DELETE_ENTRIES_MEDIA = "DROP TABLE IF EXISTS ${MediaEntry.TABLE_MEDIA}"
    const val SQL_DELETE_ENTRIES_HARMONOGRAM = "DROP TABLE IF EXISTS ${HarmonogramEntry.TABLE_HARMONOGRAM}"
    const val SQL_DELETE_ENTRIES_MODULE = "DROP TABLE IF EXISTS ${ModuleEntry.TABLE_MODULE}"
}

class DatabaseDbHelper(context: Context) : SQLiteOpenHelper(context, "DataBase", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_ENTRIES_MEDIA)
        db.execSQL(SQL_CREATE_ENTRIES_HARMONOGRAM)
        db.execSQL(SQL_CREATE_ENTRIES_MODULE)
        db.execSQL(SQL_CREATE_ENTRIES_SETTINGS)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(SQL_DELETE_ENTRIES_MODULE)
        onCreate(db)
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }

    companion object {
        const val DATABASE_VERSION = 1
        const val DATABASE_NAME = "DataBase.db"
    }
}