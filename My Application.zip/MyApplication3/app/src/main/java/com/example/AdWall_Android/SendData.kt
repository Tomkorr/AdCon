package com.example.AdWall_Android

import android.os.AsyncTask
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class SendData() :
    AsyncTask<String?, Void?, Void?>() {
    override fun doInBackground(vararg p: String?): Void? {

        val url = URL("http://tvcon.panelappscontrol.pl/api/set/")
        // 1. create HttpURLConnection

            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

            // 2. build JSON object
            val jsonObject = buildJsonObject(p[0]!!.toInt(), p[1]!!.toInt(), p[2]!!.toInt(), p[3]!!.toInt(), p[4]!!.toInt(), p[5]!!, p[6]!!)

            // 3. add JSON content to POST request body
            setPostRequestContent(conn, jsonObject)

            // 4. make POST request to the given URL
            conn.connect()

            // 5. return response message
            println(conn.responseMessage + " dsdsfd")



        return null
    }

    private fun buildJsonObject(idmedia: Int, idmediaUpdate: Int, percent: Int, idUpdate: Int, state: Int, time: String, idToken: String): JSONObject {
        return JSONObject("""{"play":{"idmedia":${idmedia}},"update":{"idmedia":${idmediaUpdate},"percent":${percent},"idUpdate":${idUpdate},"state":${state}},"time":"${time}","idToken":"${idToken}"}""")
    }


    private fun setPostRequestContent(conn: HttpURLConnection, jsonObject: JSONObject) {

        val os = conn.outputStream
        val writer = BufferedWriter(OutputStreamWriter(os, "UTF-8"))
        writer.write(jsonObject.toString())
        println(jsonObject.toString())
        writer.flush()
        writer.close()
        os.close()
    }

    override fun onPostExecute(result: Void?) {
        // TODO: check this.exception
        // TODO: do something with the feed
    }
}