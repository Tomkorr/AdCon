package com.example.AdWall_Android

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.example.AdWall_Android.DataBase.HarmonogramEntry.TABLE_COLUMN_HARMONOGRAM_ID
import com.example.AdWall_Android.DataBase.HarmonogramEntry.TABLE_HARMONOGRAM
import com.google.gson.Gson
import java.io.File
import java.net.URL
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

data class Media(
    val idMedia: Int,
    val name: String,
    val typ: Int,
    val path: String,
    val size: Int
) {
    companion object {
        fun getMediaIdByMediaName(mediaName: String, context: Context): Int {
            val dbHelper = DatabaseDbHelper(context)
            val dbR = dbHelper.readableDatabase
            val query =
                "Select ${DataBase.MediaEntry.TABLE_COLUMN_MEDIA_ID} from ${DataBase.MediaEntry.TABLE_MEDIA} where ${DataBase.MediaEntry.TABLE_COLUMN_NAME} = ?"
            val result = dbR?.rawQuery(query, arrayOf(mediaName))
            result?.moveToFirst()

            return result!!.getInt(0)
        }

        fun areMediaAvailableByHarmonogramId(harmonogramId: Int, context: Context): Boolean {
            getMediaListByHarmonogramId(harmonogramId, context).forEach {
                if (it.endsWith("jpg")) {
                    if (!storedMedia("images", context).contains(it))
                        return false
                }
                if (it.endsWith("mp4")) {
                    if (!storedMedia("videos", context).contains(it))
                        return false
                }
            }
            return true
        }

        fun getMediaListByHarmonogramId(harmonogramId: Int, context: Context): ArrayList<String> {
            val dbHelper = DatabaseDbHelper(context)
            val dbR: SQLiteDatabase? = dbHelper.readableDatabase

            val query =
                "Select ${DataBase.HarmonogramEntry.TABLE_COLUMN_MODULS_ID} from $TABLE_HARMONOGRAM where $TABLE_COLUMN_HARMONOGRAM_ID = ?"
            val result = dbR?.rawQuery(query, arrayOf(harmonogramId.toString()))
            result?.moveToFirst()
            val moduleId = result?.getInt(0)

            val selection = "${DataBase.ModuleEntry.TABLE_COLUMN_MODULE_ID} = ?"
            val selectionArgs = arrayOf(moduleId.toString())
            var mediaNames: ArrayList<String> = ArrayList()

            val cursor = dbR?.query(
                DataBase.ModuleEntry.TABLE_MODULE,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
            )
            var mediaName: Cursor? = null

            with(cursor) {
                while (this?.moveToNext()!!) {
                    try {
                        val mediaId = cursor?.getInt(cursor.getColumnIndexOrThrow("MEDIA_ID"))
                        val query =
                            "Select ${DataBase.MediaEntry.TABLE_COLUMN_NAME} from ${DataBase.MediaEntry.TABLE_MEDIA} where ${DataBase.MediaEntry.TABLE_COLUMN_MEDIA_ID} = ?"
                        mediaName = dbR?.rawQuery(query, arrayOf(mediaId.toString()))
                        mediaName?.moveToFirst()
                        mediaName?.getString(0)?.let { mediaNames.add(it) }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
            cursor?.close()
            mediaName?.close()
            return mediaNames
        }

        fun storedMedia(folderName: String, context: Context): ArrayList<String> {
            var media = arrayListOf<String>()

            File(context.getExternalFilesDir(null)?.absolutePath.toString() + "/$folderName/").walk()
                .forEach {
                    val name = it.toString().split("/")
                    media.add(name[name.size - 1])
                }
            return media
        }

        fun removeUnnecessaryMedia(
            storedMedia: ArrayList<String>,
            newMedia: ArrayList<String>,
            folderName: String,
            context: Context
        ) {
            for (fileName in storedMedia) {
                if (!newMedia.contains(fileName)) {
                    File(context.getExternalFilesDir(null)?.absolutePath.toString() + "/$folderName/$fileName").delete()
                }
            }
        }
    }

    override fun toString(): String {
        return "Media(idMedia=$idMedia, name='$name', typ=$typ, path='$path', size=$size)"
    }

    class GetMediaTask(
        private val idUpdate: Int,
        private val dbHelper: DatabaseDbHelper,
        private val context: Context
    ) :
        AsyncTask<String, String, Array<Media>>() {

        private val downloadmanager: DownloadManager =
            context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        @RequiresApi(Build.VERSION_CODES.O)
        override fun doInBackground(vararg p0: String?): Array<Media> {

            val result =
                URL(context.resources.getString(R.string.mediasURL)).readText()
            val gson = Gson()
            val mediaArray: Array<Media> =
                gson.fromJson(result, Array<Media>::class.java)
            val dbW: SQLiteDatabase? = dbHelper.writableDatabase
            var newImages: ArrayList<String> = arrayListOf()
            var newVideos: ArrayList<String> = arrayListOf()
            val warsawZone = ZoneId.of("Europe/Warsaw")
            val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
            val currentDateTime = ZonedDateTime.now(warsawZone)
            val currentHour = currentDateTime.format(formatter)
            for (media in mediaArray) {
                if (media.name.endsWith("jpg", true) || media.name.endsWith("png", true)) {
                    newImages.add(media.name)
                } else if (media.name.endsWith("mp4", true)) {
                    newVideos.add(media.name)
                }

                val values = ContentValues().apply {
                    put(DataBase.MediaEntry.TABLE_COLUMN_MEDIA_ID, media.idMedia)
                    put(DataBase.MediaEntry.TABLE_COLUMN_NAME, media.name)
                    put(DataBase.MediaEntry.TABLE_COLUMN_PATH, media.path)
                    put(DataBase.MediaEntry.TABLE_COLUMN_TYP, media.typ)
                    put(DataBase.MediaEntry.TABLE_COLUMN_SIZE, media.size)
                }
                try {
                    dbW?.insertOrThrow(DataBase.MediaEntry.TABLE_MEDIA, null, values)
                } catch (e: SQLiteException) {
                    continue
                }
                publishProgress(media.idMedia.toString(), currentHour)
                if (media.path.endsWith("jpg", true) || media.path.endsWith("png", true)) {
                    downloadMediaFromUrl(
                        media.path,
                        context.getExternalFilesDir(null)?.absolutePath.toString(),
                        "images", media.name
                    )
                } else if (media.path.endsWith("mp4", true)) {
                    downloadMediaFromUrl(
                        media.path,
                        context.getExternalFilesDir(null)?.absolutePath.toString(),
                        "videos", media.name
                    )
                }
            }
            removeUnnecessaryMedia(storedMedia("images", context), newImages, "images", context)
            removeUnnecessaryMedia(storedMedia("videos", context), newVideos, "videos", context)
            return mediaArray
        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            SendData().execute(
                MediaActivity.currentlyPlayedMedia.toString(),
                values[0],
                "100",
                idUpdate.toString(),
                "1",
                values[1],
                "F0:CE:EE:21:8A:14"
            )
        }

        override fun onPostExecute(result: Array<Media>?) {
            super.onPostExecute(result)
            MainActivity.firstLaunch = true
            var intent = Intent(context, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            println("STAAART")
            context.startActivity(intent)
        }

        fun downloadMediaFromUrl(
            url: String,
            absolutePath: String,
            directoryName: String,
            fileName: String
        ) {

            try {
                println("Downloading $fileName")
                val request: DownloadManager.Request = DownloadManager.Request(Uri.parse(url))
                request.setTitle("$fileName")
                request.setDescription("Downloading")
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setVisibleInDownloadsUi(false)
                request.setDestinationUri(Uri.parse("file://$absolutePath/$directoryName/$fileName"))

                println("procent: " + DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                downloadmanager.enqueue(request)
            } catch (e: Exception) {
                Log.e("Error: ", e.message)
            }
        }
    }


}
