package com.example.AdWall_Android

import android.content.ContentValues
import com.google.gson.Gson
import java.net.URL
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*

@RequiresApi(Build.VERSION_CODES.O)
class UpdateChecker(context: Context) : TimerTask() {

    private val context = context
    private val dbHelper = DatabaseDbHelper(context)
    private val dbW = dbHelper.writableDatabase
    private val dbR = dbHelper.readableDatabase
    val warsawZone = ZoneId.of("Europe/Warsaw")
    val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")

    override fun run() {
        updateSettings(dbHelper, context)
    }

    fun updateSettings(dbHelper: DatabaseDbHelper, context: Context) {
        val gson = Gson()
        val settings: Settings =
            gson.fromJson(
                URL(context.resources.getString(R.string.settingsURL)).readText(),
                Settings::class.java
            )
        val cursor = dbR.query(
            DataBase.SettingsEntry.TABLE_SETTINGS, null, null, null, null, null, null
        )

        cursor.moveToLast()
        //println("bar ${cursor.getString(cursor.getColumnIndexOrThrow("INFORMATION_BAR")).length}")
        if (cursor.count == 0 || cursor.getInt(cursor.getColumnIndexOrThrow("ID_SYNCH")) != settings.idSynch
            || !(cursor.getString(cursor.getColumnIndexOrThrow("INFORMATION_BAR"))
                .equals(settings.informationBar))
        ) {
            println("UPDATE")
            val values = ContentValues()
            values.put(DataBase.SettingsEntry.TABLE_COLUMN_ID_SYNCH, settings.idSynch)
            values.put(DataBase.SettingsEntry.TABLE_COLUMN_INFORMATION_BAR, settings.informationBar)
            try {
                dbW?.insertOrThrow(DataBase.SettingsEntry.TABLE_SETTINGS, null, values)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                if (NetworkChecker().isNetworkAvailable(context)) {
                    Harmonogram.GetHarmonogramTask(dbHelper, context).execute()
                    Module.GetModuleTask(dbHelper, context).execute()
                    Media.GetMediaTask(settings.idSynch, dbHelper, context).execute()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            SendData().execute(
                MediaActivity.currentlyPlayedMedia.toString(),
                "0",
                "0",
                settings.idSynch.toString(),
                "1",
                "17:38",
                "F0:CE:EE:21:8A:14"
            )
        }
        cursor.close()
    }
}