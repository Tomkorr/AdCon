package com.example.AdWall_Android

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.View
import android.webkit.WebSettings
import android.widget.TextView
import androidx.annotation.RequiresApi
import kotlinx.android.synthetic.main.activity_media.*
import java.net.NetworkInterface
import java.net.SocketException
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

@RequiresApi(Build.VERSION_CODES.O)
class MediaActivity() : Activity() {
    companion object {
        var instance: MediaActivity? = null
        var currentlyPlayedMedia: Int = 0
    }

    val warsawZone = ZoneId.of("Europe/Warsaw")
    val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
    val handler = Handler()
    var runn: ArrayList<Runnable> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media)
        instance = this

        window.decorView.apply {
            systemUiVisibility =
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN
        }

        val deviceMAC = getMacAddress("eth0")
        val intent = intent
        var myBitmap: Bitmap
        var mediaName = intent.getSerializableExtra("MediaNames") as ArrayList<String>
        var time = intent.getSerializableExtra("MediaTime") as ArrayList<Long>
        val marquee = findViewById<TextView>(R.id.informationBar)
        var information = intent.getStringExtra("informationBar")
        if (information.isEmpty())
            marquee.visibility = View.GONE
        else {
            information += "   "
            information.repeat(5)
            marquee.visibility = View.VISIBLE
            marquee.ellipsize = TextUtils.TruncateAt.MARQUEE;
            marquee.text = information.repeat(5)
            marquee.marqueeRepeatLimit = -1
            marquee.isSelected = true
        }

        var i = 0
        val r: Runnable = object : Runnable {
            override fun run() {

                val currentDateTime = ZonedDateTime.now(warsawZone)
                val currentHour = currentDateTime.format(formatter)
                currentlyPlayedMedia = Media.getMediaIdByMediaName(mediaName[i], applicationContext)
                try {
                    SendData().execute(
                        currentlyPlayedMedia.toString(),
                        "0",
                        "0",
                        "0",
                        "0",
                        currentHour,
                        "F0:CE:EE:21:8A:14"
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                println("mediaid: " + Media.getMediaIdByMediaName(mediaName[i], applicationContext).toString())

                if (mediaName[i].endsWith("jpg") || mediaName[i].endsWith("png")) {
                    imageView.visibility = View.VISIBLE
                    videoView.visibility = View.GONE
                    webView.visibility = View.GONE
                    try {
                        myBitmap =
                            BitmapFactory.decodeFile(applicationContext.getExternalFilesDir(null)?.absolutePath.toString() + "/images/${mediaName[i]}")
                        imageView.setImageBitmap(myBitmap)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else if (mediaName[i].endsWith("mp4")) {
                    videoView.visibility = View.VISIBLE
                    imageView.visibility = View.GONE
                    webView.visibility = View.GONE
                    try {
                        videoView.setVideoURI(Uri.parse(applicationContext.getExternalFilesDir(null)?.absolutePath.toString() + "/videos/${mediaName[i]}"))
                        videoView.requestFocus()
                        videoView.start()
                        videoView.setOnCompletionListener { videoView.start() }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(applicationContext.getExternalFilesDir(null)?.absolutePath.toString() + "/videos/${mediaName[i]}");
                    val duration: String? =
                        (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))
                    retriever.release()
                    if (duration != null) {
                        time[i] = duration.toLong() / 1000
                    }
                } else if (mediaName[i].endsWith("avi")) {
                    webView.visibility = View.VISIBLE
                    videoView.visibility = View.GONE
                    imageView.visibility = View.GONE
                    webView.webViewClient = MyWebViewClient()
                    webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
                    webView.settings.setJavaScriptEnabled(true)
                    webView.settings.domStorageEnabled
                    webView.settings.javaScriptCanOpenWindowsAutomatically = true
                    webView.settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
                    webView.loadUrl("https://omero.pl/")
                }
                //println("czas ${time[i]}")
                handler.postDelayed(this, time[i] * 1000)
                i++
                if (i == mediaName.size)
                    i = 0
            }
        }
        runn.add(r)

        handler.post(r)
    }

    override fun finish() {
        super.finish()
        println("FINISH MEDIA ${runn[0].toString()}")
        instance = null
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(runn[0])
        //MainActivity.firstLaunch = true
        println("STOPPED MEDIA ACTIVITY")
    }

    override fun onDestroy() {
        super.onDestroy()
        println("MEDIA DESTROYED")
    }

    fun getMacAddress(interfaceName: String): String {
        return try {
            val interfaces: Enumeration<NetworkInterface> =
                NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface: NetworkInterface = interfaces.nextElement()
                if (TextUtils.equals(networkInterface.name, interfaceName)) {
                    val bytes = networkInterface.hardwareAddress
                    val builder = StringBuilder()
                    for (b in bytes) {
                        builder.append(String.format("%02X:", b))
                    }
                    if (builder.length > 0) {
                        builder.deleteCharAt(builder.length - 1)
                    }
                    return builder.toString()
                }
            }
            "<EMPTY>"
        } catch (e: SocketException) {
            e.printStackTrace().toString()
        }
    }

}