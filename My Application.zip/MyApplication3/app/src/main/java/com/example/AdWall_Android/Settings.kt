package com.example.AdWall_Android

class Settings(val idSynch: Int, val informationBar: String) {
    override fun toString(): String {
        return "Settings(idSynch=$idSynch, informationVar='$informationBar')"
    }
}