package com.example.AdWall_Android

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.os.AsyncTask
import com.example.AdWall_Android.DataBase.HarmonogramEntry.TABLE_HARMONOGRAM
import com.google.gson.Gson
import java.net.URL

data class Harmonogram(
    val idHarmonogram: Int,
    val idModuls: Int,
    val idDay: Int,
    val timeStart: String,
    val timeStop: String
) {
    override fun toString(): String {
        return "Harmonogram(idHarmonogram=$idHarmonogram, idModuls=$idModuls, idDay=$idDay, timeStart='$timeStart', timeStop='$timeStop')"
    }

    class GetHarmonogramTask(val dbHelper: DatabaseDbHelper, val context: Context) :
        AsyncTask<Unit, Unit, Array<Harmonogram>>() {

        override fun doInBackground(vararg params: Unit?): Array<Harmonogram> {
            val result =
                URL(context.resources.getString(R.string.harmonogramsURL)).readText()
            val gson = Gson()
            val harmonogramArray: Array<Harmonogram> =
                gson.fromJson(result, Array<Harmonogram>::class.java)
            val dbW = dbHelper.writableDatabase
            dbW.execSQL("DELETE FROM $TABLE_HARMONOGRAM")
            for (harmonogram in harmonogramArray) {
                val values = ContentValues().apply {
                    put(
                        DataBase.HarmonogramEntry.TABLE_COLUMN_HARMONOGRAM_ID,
                        harmonogram.idHarmonogram
                    )
                    put(DataBase.HarmonogramEntry.TABLE_COLUMN_MODULS_ID, harmonogram.idModuls)
                    put(DataBase.HarmonogramEntry.TABLE_COLUMN_DAY_ID, harmonogram.idDay)
                    put(DataBase.HarmonogramEntry.TABLE_COLUMN_TIME_START, harmonogram.timeStart)
                    put(DataBase.HarmonogramEntry.TABLE_COLUMN_TIME_STOP, harmonogram.timeStop)
                }
                try {
                    dbW?.insertOrThrow(DataBase.HarmonogramEntry.TABLE_HARMONOGRAM, null, values)
                } catch (e: SQLiteConstraintException) {
                    continue
                }
            }
            return harmonogramArray
        }
    }
}