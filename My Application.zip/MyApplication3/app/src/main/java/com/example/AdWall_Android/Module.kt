package com.example.AdWall_Android

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.os.AsyncTask
import com.google.gson.Gson
import java.net.URL

data class Module(val idModule: Int, val name: String, val list: Array<List>) {
    override fun toString(): String {
        return "Module(idModule=$idModule, name='$name', list=$list)"
    }

    data class List(val idMedia: Int, val time: Int) {
        override fun toString(): String {
            return "list(idMedia=$idMedia, time=$time)"
        }
    }

    class GetModuleTask(val dbHelper: DatabaseDbHelper, val context: Context) : AsyncTask<Unit, Unit, Array<Module>>() {

        override fun doInBackground(vararg params: Unit?): Array<Module> {

            val result =
                URL(context.resources.getString(R.string.modulesURL)).readText()
            val gson = Gson()
            val moduleArray: Array<Module> =
                gson.fromJson(result, Array<Module>::class.java)
            val dbW = dbHelper.writableDatabase
            val values = ContentValues()
            dbW.execSQL("DELETE FROM ${DataBase.ModuleEntry.TABLE_MODULE}")
            for (module in moduleArray) {
                for (item in module.list) {
                    values.put(DataBase.ModuleEntry.TABLE_COLUMN_MODULE_ID, module.idModule)
                    values.put(DataBase.ModuleEntry.TABLE_COLUMN_NAME, module.name)
                    values.put(DataBase.ModuleEntry.TABLE_COLUMN_MEDIA_ID, item.idMedia)
                    values.put(DataBase.ModuleEntry.TABLE_COLUMN_TIME, item.time)
                    try {
                        dbW?.insertOrThrow(DataBase.ModuleEntry.TABLE_MODULE, null, values)
                    } catch (e: SQLiteConstraintException) {
                        continue
                    }
                }
            }
            return moduleArray
        }
    }
}
