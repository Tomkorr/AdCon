package com.example.AdWall_Android

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.annotation.RequiresApi
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.*


class MainActivity : Activity() {
    companion object {
        var firstLaunch = true
    }

    /*fun getIPAddress(useIPv4: Boolean): String? {
        try {
            val interfaces: List<NetworkInterface> =
                Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs: List<InetAddress> =
                    Collections.list(intf.getInetAddresses())
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress()) {
                        val sAddr: String = addr.getHostAddress()
                        //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                        val isIPv4 = sAddr.indexOf(':') < 0
                        if (useIPv4) {
                            if (isIPv4) return sAddr
                        } else {
                            if (!isIPv4) {
                                val delim = sAddr.indexOf('%') // drop ip6 zone suffix
                                return if (delim < 0) sAddr.toUpperCase() else sAddr.substring(
                                    0,
                                    delim
                                ).toUpperCase()
                            }
                        }
                    }
                }
            }
        } catch (ignored: Exception) {
        } // for now eat exceptions
        return ""
    }*/

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.decorView.apply {
            systemUiVisibility =
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN
        }
        val handler = Handler()
        val warsawZone = ZoneId.of("Europe/Warsaw")
        val r: Runnable = object : Runnable {
            override fun run() {
                val warsawCurrentDateTime = ZonedDateTime.now(warsawZone)
                time.text = warsawCurrentDateTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
                date.text = warsawCurrentDateTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
                handler.postDelayed(this, 1000)

            }
        }
        handler.post(r)

        //SendData().execute("2468")
        val dbHelper = DatabaseDbHelper(applicationContext)
//        var mediaId = getMediaIdByMediaName(dbHelper, "3lions_1.mp4")
        // println("mediaId: $mediaId")

        directoryCreate("informations")
        directoryCreate("images")
        directoryCreate("videos")

        val timer = Timer()

        val updateSettings = UpdateChecker(applicationContext)
        val checkTime = TimeChecker(applicationContext)

        if (NetworkChecker().isNetworkAvailable(applicationContext)) {
            timer.schedule(updateSettings, 0, 1000 * 60)
        }
        timer.schedule(checkTime, 10000, 1000 * 60)
    }

    override fun onDestroy() {
        super.onDestroy()
        firstLaunch = true
        println("DESTROYED")
    }

    override fun onRestart() {
        super.onRestart()
        firstLaunch = true
        println("ON RESTART")
    }

    override fun onBackPressed() {
        super.onBackPressed()
        firstLaunch = true
        println("BACK PRESSED")
    }

    fun directoryCreate(directoryName: String) {
        val newDir =
            File(applicationContext.getExternalFilesDir(null)?.absolutePath.toString() + "/$directoryName/")
        val isNewDirectoryCreated: Boolean = newDir.mkdir()

        if (isNewDirectoryCreated) {
            println("$directoryName is created successfully.")
        } else {
            println("$directoryName already exists.")
        }
    }

    fun folderSize(folderName: String): Int {
        var i = 0
        File(applicationContext.getExternalFilesDir(null)?.absolutePath.toString() + "/$folderName/").walk()
            .forEach {
                i++
            }
        return i
    }

    /*fun getMediaIdByMediaName(
        dbHelper: DatabaseDbHelper,
        mediaName: String
    ): Int {

        val dbR = dbHelper.readableDatabase
        val query =
            "Select ${DataBase.MediaEntry.TABLE_COLUMN_MEDIA_ID} from ${DataBase.MediaEntry.TABLE_MEDIA} where ${DataBase.MediaEntry.TABLE_COLUMN_NAME} = ?"
        val result = dbR?.rawQuery(query, arrayOf(mediaName))
        result?.moveToFirst()

        return result!!.getInt(0)
    }*/
}