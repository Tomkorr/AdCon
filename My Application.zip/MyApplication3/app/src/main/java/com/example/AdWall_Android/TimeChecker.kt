package com.example.AdWall_Android

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.File
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*

@RequiresApi(Build.VERSION_CODES.O)
class TimeChecker(val context: Context) : TimerTask() {

    val warsawZone = ZoneId.of("Europe/Warsaw")
    val formatter = DateTimeFormatter.ofPattern("HH:mm")
    val dbHelper = DatabaseDbHelper(context)
    val dbR = dbHelper.readableDatabase
    var mediaIntent = Intent(context, MediaActivity::class.java)

    override fun run() {
        val currentDateTime = ZonedDateTime.now(warsawZone)
        val dow: DayOfWeek = currentDateTime.dayOfWeek
        var harmonograms = getHarmonogramsByDay(dow.value)

        val currentHour = currentDateTime.format(formatter)
        val target: LocalTime = LocalTime.parse(currentHour)
        File(context.getExternalFilesDir(null)?.absolutePath.toString() + "/images/").walk()
            .forEach {
                println(it)
            }
        for (h in harmonograms) {
            println("timestart: ${h.timeStart} timestop: ${h.timeStop}  ${h.idModuls} ${h.idHarmonogram} ${dow.value}")
            if (!MainActivity.firstLaunch) {
                if (currentHour.equals(fixHour(h.timeStart)) && Media.areMediaAvailableByHarmonogramId(
                        h.idHarmonogram,
                        context
                    )
                ) {
                    mediaInformationsIntent(h.idModuls)
                    break
                }
            } else {
                if (target.isAfter(LocalTime.parse(fixHour(h.timeStart))) && target.isBefore(
                        LocalTime.parse(fixHour(h.timeStop))
                    ) &&
                    Media.areMediaAvailableByHarmonogramId(h.idHarmonogram, context)
                ) {
                    MainActivity.firstLaunch = false
                    mediaInformationsIntent(h.idModuls)
                    break
                }
            }
            if (currentHour.equals(fixHour(h.timeStop))) {
                MediaActivity.currentlyPlayedMedia = 0
                MediaActivity.instance?.finish()
            }
        }
    }

    fun mediaInformationsIntent(idModuls: Int) {
        var mediaNames = ArrayList<String>()
        var mediasTime = ArrayList<Long>()
        val cursor = dbR.query(
            DataBase.SettingsEntry.TABLE_SETTINGS, null, null, null, null, null, null
        )
        cursor.moveToLast()
        val informationBar = cursor.getString(cursor.getColumnIndexOrThrow("INFORMATION_BAR"))
        for ((n, t) in getMediasAndTimeById(idModuls)) {
            mediaNames.add(n)
            mediasTime.add((t).toLong())
            println("$n $t")
        }
        mediaIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        mediaIntent.putExtra("MediaNames", mediaNames)
        mediaIntent.putExtra("MediaTime", mediasTime)
        mediaIntent.putExtra("informationBar", informationBar)
        context.startActivity(mediaIntent)
    }

    fun getHarmonogramsByDay(day: Int): List<Harmonogram> {
        val harmonograms: ArrayList<Harmonogram> = ArrayList()
        val selection = "${DataBase.HarmonogramEntry.TABLE_COLUMN_DAY_ID} = ?"
        val selectionArgs = arrayOf(day.toString())

        val cursor = dbR.query(
            DataBase.HarmonogramEntry.TABLE_HARMONOGRAM,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        with(cursor) {
            while (moveToNext()) {
                val h = Harmonogram(
                    cursor.getInt(cursor.getColumnIndexOrThrow("HARMONOGRAM_ID")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("MODULS_ID")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("DAY_ID")),
                    cursor.getString(cursor.getColumnIndexOrThrow("TIME_START")),
                    cursor.getString(cursor.getColumnIndexOrThrow("TIME_STOP"))
                )
                harmonograms.add(h)
            }
        }
        cursor.close()

        return harmonograms
    }

    fun fixHour(hour: String): String {

        var hourArr = hour.split(":").toTypedArray()

        if (hourArr[0].length < 2)
            hourArr[0] = "0" + hourArr[0]

        if (hourArr[1].length < 2)
            hourArr[1] = "0" + hourArr[1]

        return hourArr[0] + ":" + hourArr[1]
    }

    fun getMediasAndTimeById(moduleId: Int): LinkedHashMap<String, Int> {
        val selection = "${DataBase.ModuleEntry.TABLE_COLUMN_MODULE_ID} = ?"
        val selectionArgs = arrayOf(moduleId.toString())
        val cursor = dbR.query(
            DataBase.ModuleEntry.TABLE_MODULE,
            null,
            null,
            null,
            null,
            null,
            null
        )

        var mediaTimeMap: LinkedHashMap<String, Int> = LinkedHashMap()

        cursor.moveToFirst()
        while (!cursor.isAfterLast) {

            try {
                if (cursor.getInt(cursor.getColumnIndexOrThrow("MODULE_ID")) == moduleId) {
                    mediaTimeMap[getMediaNameById(cursor.getInt(cursor.getColumnIndexOrThrow("MEDIA_ID")))] =
                        cursor.getInt(cursor.getColumnIndexOrThrow("TIME"))
                }
                cursor.moveToNext()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        cursor.close()

        return mediaTimeMap
    }

    fun getMediaNameById(mediaId: Int): String {
        val selection = "${DataBase.MediaEntry.TABLE_COLUMN_MEDIA_ID} = ?"
        val selectionArgs = arrayOf(mediaId.toString())
        val cursor = dbR.query(
            DataBase.MediaEntry.TABLE_MEDIA,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        )
        cursor.moveToFirst()
        var mediaName = cursor.getString(cursor.getColumnIndexOrThrow("NAME"))

        cursor.close()

        return mediaName
    }
}